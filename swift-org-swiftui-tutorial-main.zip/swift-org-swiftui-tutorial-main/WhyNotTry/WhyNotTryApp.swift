//
//  WhyNotTryApp.swift
//  WhyNotTry
//
//  Created by Tim Condon on 14/02/2023.
//

import SwiftUI

@main
struct WhyNotTryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
